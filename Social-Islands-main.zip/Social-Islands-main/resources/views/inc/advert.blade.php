<div class="ui placeholder">
  <div class="image">
    <img height="500" />
  </div>
</div>
