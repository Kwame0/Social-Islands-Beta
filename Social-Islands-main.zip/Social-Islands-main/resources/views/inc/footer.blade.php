<!--<footer class="footer has-background-dark is-fixed-bottom">
  <div class="tile is-ancestor">
    <div class="tile is-parent">
      <div class="tile is-child box has-background-dark">
        <p class="has-text-centered title is-6 has-text-white-bis"><b>Information</b></p>
        <p><a  href="https://discord.gg/hERsWfC" class="has-text-white-bis"><i class="fab fa-discord fa-fw"></i> Discord</a></p>
        <p><a class="has-text-white-bis">Positions</a></p>
        <p><a class="has-text-white-bis">Documentation</a></p>
        <p><a class="has-text-white-bis">Contact</a></p>
      </div>
    </div>
    <div class="tile is-parent">
      <div class="tile is-child box has-background-dark">
        <p class="has-text-centered title is-6 has-text-white-bis"><b>Documentation</b></p>
        <p><a class="has-text-white-bis">Index</a></p>
        <p><a class="has-text-white-bis">Social Script</a></p>
        <p><a class="has-text-white-bis">P.I.E</a></p>
      </div>
    </div>
    <div class="tile is-parent">
      <div class="tile is-child box has-background-dark">
        <p class="has-text-centered title is-6 has-text-white-bis"><b>Contact</b></p>
        <p><a class="has-text-white-bis">Staff list</a></p>
        <p><a class="has-text-white-bis">Web master</a></p>
      </div>
    </div>
  </div>
  <div class="content has-text-centered">
	<nav class="level">
	  <p class="level-item has-text-centered title has-text-white-bis">
  		<b>Social Islands</b>
	  </p>
	</nav><br><br>Richardlabs &copy; 2019
  </div>
</footer>-->
</div>
