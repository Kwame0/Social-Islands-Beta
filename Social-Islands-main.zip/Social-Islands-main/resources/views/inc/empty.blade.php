<div class="ui grid">
    <div class="four wide column">
      X
    </div>
    <div class="eight wide column">
      X
    </div>
    <div class="four wide column">
      <div class="ui placeholder">
        @include("inc.advert");
      </div>
    </div>
  <div class="ui grid">
