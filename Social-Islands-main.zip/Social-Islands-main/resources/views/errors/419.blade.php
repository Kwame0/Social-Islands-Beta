@extends('app')

@section('title', '419 Error')

@section('pagetitle', 'Oh no!')

@section('content')
  Please try again later.<br><br>
  <img style="width:20%;height:20%;" src="/imgs/landing/landingpromo3.png">
@endsection

@section('footer')
