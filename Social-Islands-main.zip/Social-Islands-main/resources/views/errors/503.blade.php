@extends('app')

@section('title', '503 Error')

@section('pagetitle', 'Wait here whilst we preform some upgrades!')

@section('content')
  We are maintaining the website and deploying new features!<br><br>
  <img style="width:20%;height:20%;" src="/imgs/landing/landingpromo3.png">
@endsection

@section('footer')
