@extends('app')

@section('title', '404 Error')

@section('pagetitle', 'An error occured!')

@section('content')
  Object or resource not found<br><br>
  <img style="width:20%;height:20%;" src="/imgs/landing/landingpromo3.png">
@endsection

@section('footer')
