@extends('appsite')

@section('title', 'Verification')

@section('pagetitle', '')

@section('content')

<div class="ui grid">
  <div class="four wide column">
    @include('inc.panel.indicator')
  </div>
  <div class="twelve wide column">
    <h1>Staff Panel</h1>
    <i>Nothing really cool yet</i>
  </div>
  <!--<div class="two wide column"></div>-->
</div>

@endsection

@section('footer')
