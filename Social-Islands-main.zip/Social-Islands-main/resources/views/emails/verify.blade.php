<!DOCTYPE html>
<html>
<head>
<title>Verification</title>
</head>
<body style="font-family:sans-serif;font-weight:bold;">
<h4>Social Islands</h4>
<h1>It's time to verify {{$user->username}}!</h1>
Click <a href="https://{{$Domain}}/v/{{$Hash}}">Here</a> to verify. Or copy the link below and paste it into your browser's bar<br><br>
<i>https://{{$Domain}}/v/{{$Hash}}</i><br><br>

(c) Social Islands 2019
</body>
</html>
