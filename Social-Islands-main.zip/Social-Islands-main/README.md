<div align="center">
    <img src="git.png"></img>
    <br>
    https://socialislands.net
</div>

# Social Islands

An Unconcluded Experimental 2D Social Avatar Networking Site

rename .env.si to .env

#### Copyright Disclaimer

*Copyright Disclaimer under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research.*

*Fair use is a use permitted by copyright statute that might otherwise be infringing.*

*Non-profit, educational or personal use tips the balance in favor of fair use.*
